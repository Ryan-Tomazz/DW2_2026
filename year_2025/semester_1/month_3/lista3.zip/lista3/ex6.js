estoque(113,23)

function estoque(refri, comida, agua = 5){
    console.log("estoque de "+refri)
    console.log("estoque de "+comida)
    console.log("estoque de "+agua)
}

